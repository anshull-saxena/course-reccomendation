be_index = cdcs.index(be)
if(msc!='None'):
    msc_index = cdcs.index(msc)
else:
    msc_index = None